import{default as t}from"../components/pages/(editor)/_layout.svelte-9be87f32.js";export{t as component};
