import{default as t}from"../components/pages/(app)/_page.svelte-f53bd645.js";export{t as component};
