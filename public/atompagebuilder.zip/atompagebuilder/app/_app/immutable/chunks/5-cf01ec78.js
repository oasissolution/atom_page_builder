import{default as t}from"../components/pages/(editor)/editor/_page.svelte-be3fa837.js";export{t as component};
