import{default as t}from"../components/pages/(app)/_layout.svelte-fae26e28.js";export{t as component};
