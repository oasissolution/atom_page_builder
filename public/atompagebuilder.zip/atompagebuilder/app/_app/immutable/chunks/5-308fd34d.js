import{default as t}from"../components/pages/(editor)/editor/_page.svelte-9e4f41a6.js";export{t as component};
