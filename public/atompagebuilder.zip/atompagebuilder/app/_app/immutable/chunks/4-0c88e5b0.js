import{default as t}from"../components/pages/(app)/_page.svelte-a5eac15a.js";export{t as component};
