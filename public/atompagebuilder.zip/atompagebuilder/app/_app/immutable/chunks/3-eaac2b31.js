import{default as t}from"../components/pages/(editor)/_layout.svelte-89f7295e.js";export{t as component};
