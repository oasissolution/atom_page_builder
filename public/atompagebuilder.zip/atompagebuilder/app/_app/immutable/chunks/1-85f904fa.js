import{default as t}from"../components/error.svelte-a8526b3b.js";export{t as component};
