import{default as t}from"../components/error.svelte-f0dccb1a.js";export{t as component};
