import{default as t}from"../components/pages/(app)/_layout.svelte-eee1a421.js";export{t as component};
