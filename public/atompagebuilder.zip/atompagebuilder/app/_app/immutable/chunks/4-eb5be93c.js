import{default as t}from"../components/pages/(app)/_page.svelte-ef5c99fe.js";export{t as component};
