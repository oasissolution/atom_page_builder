import{default as t}from"../components/pages/(editor)/_layout.svelte-71339d48.js";export{t as component};
