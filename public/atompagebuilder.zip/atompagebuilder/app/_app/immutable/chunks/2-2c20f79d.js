import{default as t}from"../components/pages/(app)/_layout.svelte-c4f44f97.js";export{t as component};
