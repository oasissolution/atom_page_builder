import{default as t}from"../components/pages/(editor)/editor/_page.svelte-6a00022a.js";export{t as component};
