import{default as t}from"../components/pages/(app)/_page.svelte-c9c9bfdb.js";export{t as component};
