import{default as t}from"../components/error.svelte-f8ec66c3.js";export{t as component};
