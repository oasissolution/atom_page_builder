import{default as t}from"../components/pages/(app)/_layout.svelte-1ddc74da.js";export{t as component};
