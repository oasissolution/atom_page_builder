import{default as t}from"../components/pages/(editor)/editor/_page.svelte-e64638e9.js";export{t as component};
